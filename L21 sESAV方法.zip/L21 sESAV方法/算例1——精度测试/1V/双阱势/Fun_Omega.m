function [w] = Fun_Omega(t, bet)
% omega ����

w = t^(bet-1)/gamma(bet); 

end

