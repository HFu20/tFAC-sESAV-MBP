clc,clear

alp = 0.9;

sig = alp/2;

m = 1;
epsilon = 0.01;
h = 1/128;
S = 8.02;

a = ( 4/( 11 * sig * m * ( 4 * epsilon^2/h^2 + S ) * gamma( 2 - alp ) ) )^(alp)
b = ( 4/( 11 * ( 1 - sig ) * m * ( 4 * epsilon^2/h^2 + S ) * gamma( 2 - alp ) ) )^(alp)
c = ( 4/( 11 * m * ( 4 * epsilon^2/h^2 + S ) * gamma( 2 - alp ) ) )^(alp)
