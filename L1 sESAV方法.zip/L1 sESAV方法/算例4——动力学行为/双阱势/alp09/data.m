clc,clear

%% 模型参数
alp = 0.9;
% sigma = 0.4; 
c = 1; % 迁移率
epsilon = 0.01; % 界面宽度

%% 求解区域
T = 700;
a = 0;  b = 1;

%% 时间网格剖分参数
% Nt = 5 * 10^(-1) * T;
% gam = 1;
gam = (2-alp)/alp; % 网格分级参数

%% 时间网格剖分
T0 = 0.5;
N0 = 30;

% [0,T0]——分级网格
t = T0 * ((0:1:N0)'/N0).^(gam);  % 时间分级网格
tau = diff( t );  % 分级网格步长

% [T0,T]——自适应网格
tau_min = 0.02;
tau_max = 2;
bet = 10^7;
Nt = 10^13;

%% 空间网格剖分
Nx = 128;  % 空间网格剖分次数
hx = (b-a)/Nx;  % mesh size
x = (a+hx:hx:b)';  % mesh grid

%% 稳定化
S = 2; % 稳定化常数

%% 问题初值
% uu = load('u_intal_08.mat');
% u_2 = uu.u_2;
% u = reshape( u_2, Nx^2, 1 );
%% 问题初值
theta = atan( (x - 0.5*b) * ones(1,Nx)./(ones( Nx, 1 ) * (x' - 0.5*b)) );
rr = sqrt( ( (x - 0.5*b)* ones(1,Nx) ).^2 + (ones( Nx, 1 ) * (x' - 0.5*b)).^2 );

u_2 = tanh( ( 1.5 + 1.2 * cos( 6*theta ) - 2*pi*rr )/( sqrt( 2 ) * 0.01 ) );
u_2(end/2,end/2) = 1;
u = reshape( u_2, Nx^2, 1 );

u_max(1,1) = max( abs( u(:,1) ) );

%figure(1);
[X, Y] = meshgrid(x, x);
% contourf(X, Y, u_2, 5)
% colormap( 'jet' );
% colorbar;

% surf(X,Y,u_2)
% shading interp
% colormap( 'jet' );
% colorbar
% view([90, 90]);
% axis off;
