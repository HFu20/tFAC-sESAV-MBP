clc,clear

%% 模型参数
alp = 0.8;
sigma = 0.4; 
c = 0.01; % 迁移率
epsilon = 1; % 界面宽度

theta = 0.8;
theta_c = 1.6;

%% 求解区域
T = 0.5;
a = 0;  b = 2 * pi;

%% 时间网格剖分参数
Nt = 320;
gam = 2;
% gam = (2-alp)/sigma; % 网格分级参数

%% 时间网格剖分
T0 = min( [ 1/gam, T ]' );
N0 = ceil( Nt/( T + 1 - 1/gam ) );

% [0,T0]——分级网格
t0 = T0 * ((0:1:N0)'/N0).^(gam);  % 时间分级网格
tau0 = diff( t0 );  % 分级网格步长

% [T0, T]——分级网格
N1 = Nt - N0;
%s_t = rand(N1,1);
s_t = ones(N1,1);
tau1 = (T - T0) * s_t/(sum(s_t));

tau = [tau0; tau1];
t = t0;
for k = 1:N1
    t(end+1,1) = t(end,1) + tau1( k, 1 );
end

%% 空间网格剖分
Nx = 400;  % 空间网格剖分次数
hx = (b-a)/Nx;  % mesh size
x = (a+hx:hx:b)';  % mesh grid

%% 稳定化
S = 8.02; % 稳定化常数

%% 问题初值
V_2 = kron( sin(x), sin(x) );
u(:,1) = Exact_Solution(sigma, 0, V_2);